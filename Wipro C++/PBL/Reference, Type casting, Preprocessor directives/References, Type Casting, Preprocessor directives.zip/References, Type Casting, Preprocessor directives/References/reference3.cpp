#include <iostream>
using namespace std; 
void test(const char *str)
{
    cout << str;
}
 int main()
 {
     test("success");     
 }