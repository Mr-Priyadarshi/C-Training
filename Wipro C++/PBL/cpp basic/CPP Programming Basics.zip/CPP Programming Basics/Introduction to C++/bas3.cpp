#include<iostream>
using namespace std;
int main()
{
	float a,b,c,d,e;
	cout<<"Enter five float type integer:\n";
	cin>>a>>b>>c>>d>>e;
	cout<<"Float type integers are: "<<a<<" , "<<b<<" , "<<c<<" , "<<d<<" , "<<e;
}
