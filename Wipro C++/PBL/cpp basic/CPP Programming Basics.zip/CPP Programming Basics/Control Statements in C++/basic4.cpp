#include<iostream>
using namespace std;
int main()
{
	int a;
	cout<<"Enter a number: ";
	cin>>a;
	if(a>0)
	cout<<a<<" is a positive number";
		if(a<0)
	cout<<a<<" is a negative number";
		if(a==0)
	cout<<a<<" is neither negative or positive";
}
