#include<iostream>
using namespace std;
int main()
{
	int a;
	cout<<"Enter an Integer: ";
	cin>>a;
	cout<<"Increment Value is: "<<++a;
}
