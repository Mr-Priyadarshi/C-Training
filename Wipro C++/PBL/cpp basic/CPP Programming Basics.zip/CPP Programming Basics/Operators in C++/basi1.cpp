
#include<iostream>
using namespace std;
int main()
{
	int a,b,c,d,e;
	float av;
	cout<<"Enter the five integer:\n";
	cin>>a>>b>>c>>d>>e;
	av=(a+b+c+d+e)/5;
	cout<<"Average of "<<a<<" , "<<b<<" , "<<c<<" , "<<d<<" , "<<e <<" = "<<av;
	return 0;
}
