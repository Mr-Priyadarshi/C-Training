#include<iostream>
using namespace std;
int main()
{
	int a,b,Greater;
	cout<<"Enter two integer type number:\n";
	cin>>a>>b;
	Greater=a>b?a:b;
	cout<<"Greater number is: "<<Greater;
}
