#include<iostream>
using namespace std;
int main()
{
	int a,b;
	cout<<"Enter the two integer type number:\n";
	cin>>a>>b;
	cout<<"Expected Output:\n";
	cout<<"Sum of the two numbers is "<<a+b<<endl;
	cout<<"Difference of the two numbers is "<<a-b;
}
