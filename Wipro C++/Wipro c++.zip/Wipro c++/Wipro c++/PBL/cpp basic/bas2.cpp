#include<iostream>
using namespace std;
int main()
{
	int a,b,c;
	cout<<"Enter three integer:\n";
	cin>>a>>b>>c;
	cout<<"Integers are: "<<a<<" , "<<b<<" , "<<c;
}
