#include<iostream>
#include<string.h>
using namespace std;

int main()
{
	char a[20],b[20];
	cout<<"Enter the first string :\n";
	cin>>a;
	cout<<"Enter the Second string :\n";
	cin>>b;
	if(strcmp (a,b) != 0)
	cout<<"**Entered strings are not identical**";


	}
