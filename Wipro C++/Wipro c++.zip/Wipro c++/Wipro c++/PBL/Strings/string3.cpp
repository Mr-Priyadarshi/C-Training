#include<iostream>
using namespace std;

int main()
{
	string a,b;
	cout<<"Enter the first string :\n";
	cin>>a;
	cout<<"Enter the Second string :\n";
	cin>>b;
	if(a==b)
	cout<<"**Entered strings are identical**";
	else
	cout<<"**Entered strings are not identical**";
	

	}
