#include<iostream>
using namespace std;

int main()
{
string a;
cout<<"Enter the String: \n";
cin>>a;
cout<<a;
}